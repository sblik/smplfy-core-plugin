<?php
namespace SmplfyCore;
class SMPLFYGravityFormsKeys {
	const ENTRY_PARENT_KEY = 'gpnf_entry_parent';
	const ENTRY_PARENT_FORM_KEY = 'gpnf_entry_parent_form';
	const ENTRY_NESTED_FORM_FIELD_KEY = 'gpnf_entry_nested_form_field';
}